#include <math.h>

double f1(double x) {
    return x * sqrt(x);
}
