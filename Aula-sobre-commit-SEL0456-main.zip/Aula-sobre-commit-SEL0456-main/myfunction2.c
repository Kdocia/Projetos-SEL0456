#include <math.h>

double f2(double x){
    return sqrt(f1(x));
}
