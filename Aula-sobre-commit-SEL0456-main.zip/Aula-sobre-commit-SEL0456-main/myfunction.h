#pragma once

double f1(double);
