#ifndef _myfunction_h // ou #pragma once
#define _myfunction_h

double f2(double);

#endif
